Revenue Media Lab logo files

rml-lockup-horizontal.svg           primary, for cream/light backgrounds
rml-lockup-horizontal-reversed.svg  for deep green / dark backgrounds
rml-lockup-stacked.svg              narrow spaces
rml-mark-green.svg                  mark only, light backgrounds
rml-mark-cream.svg                  mark only, dark backgrounds

Wordmark font: Anton (Google Fonts). The SVGs reference it via webfont import,
so it renders correctly in browsers. For print or design tools, open the SVG,
select the text and convert to outlines (Illustrator/Figma: Type > Create Outlines).

Colors
#14392A  deep green (wordmark, tube outlines)
#1F5B3F  accent green ("LAB", tube fill)
#7FC79B  light accent ("LAB" on dark)
#3E8A63  tube fill on dark
#F5F1E8 / #FAF7F0  creams
